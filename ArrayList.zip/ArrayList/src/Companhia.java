import java.util.ArrayList;

public class Companhia {
    private String nomeSocial;
    private String cnpj;
    ArrayList<Voo> voos = new ArrayList<Voo>();


    public Companhia() {
    }

    public String getNomeSocial() {
        return nomeSocial;
    }

    public void setNomeSocial(String nomeSocial) {
        this.nomeSocial = nomeSocial;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
}
